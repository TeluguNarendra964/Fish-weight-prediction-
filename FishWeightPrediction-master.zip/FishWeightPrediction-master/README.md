# FishWeightPrediction
Predicts the Weight of the Fish using the dataset from https://www.kaggle.com/aungpyaeap/fish-market using ML algorithims
